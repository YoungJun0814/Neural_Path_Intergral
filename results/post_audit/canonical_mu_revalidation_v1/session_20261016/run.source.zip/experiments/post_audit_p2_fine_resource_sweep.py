"""Fixed N4096 bridge/particle allocation pilot; no accuracy authorization."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
from pathlib import Path
from typing import Any

import psutil
import torch

from experiments.post_audit_p2_paired_gradient import CELLS
from experiments.post_audit_r1_diagnostics import _problem
from experiments.post_audit_r2_family_diagnosis import freeze_source
from src.path_integral.gradient_umbrella_smc import estimate_gradient_umbrella_normalizers
from src.path_integral.paired_normalizer_difference import paired_normalizer_difference
from src.path_integral.paired_volterra_gradient_reference import PairedVolterraProbability
from src.path_integral.recovery_checkpoint import RecoveryJournal
from src.path_integral.reference_shards import write_json_atomic_nonoverwriting
from src.path_integral.structural_v2_inventory import audit_snapshot
from src.path_integral.structural_v2_reference import log_moments, sensitivity
from src.path_integral.weighted_tempered_smc import WeightedSMCConfig

ROOT = Path(__file__).resolve().parents[1]
ANCHOR = "results/post_audit/p2_paired_fine_extension_v1/session_20261010/result.json"
PLAN = "docs/plans/POST_RECOVERY_NEXT_PRIORITIES_2026-10-16_KO.md"
DIRECTORY = "results/post_audit/p2_fine_resource_v1/session_20261016"
DESIGNS = {"more-temperatures": (128, 128), "more-particles": (256, 64)}


def jobs() -> list[dict[str, Any]]:
    return [{"cell": c, "design": d, "rep": r} for c in CELLS for d in DESIGNS for r in range(8)]


def identity(j: dict[str, Any]) -> str:
    return f"{j['cell']}-{j['design']}-{j['rep']}"


def seed(j: dict[str, Any]) -> int:
    return int(hashlib.sha256(("paired-fine-resources-v1/"+identity(j)).encode()).hexdigest()[:15], 16)


def joint_work(j: dict[str, Any]) -> int:
    p, points = DESIGNS[j["design"]]
    return p*(1+4*(points-2))


def prepare(config: dict[str, Any]) -> dict[str, PairedVolterraProbability]:
    return {c["id"]: PairedVolterraProbability.create(_problem(config["model"], c, 4096)) for c in config["cells"]}


def unit_values(j: dict[str, Any], paired: PairedVolterraProbability) -> dict[str, Any]:
    begin = time.perf_counter()
    particles, points = DESIGNS[j["design"]]
    cfg = WeightedSMCConfig(particles, tuple((k/(points-1))**2 for k in range(points)), 4, .35, 1, seed(j),
                            resample_every=4, resampling_scheme="stratified")
    r = estimate_gradient_umbrella_normalizers(paired.log_components, dimension=paired.dimension,
                                               log_mixture_weights=torch.full((2,), .5, dtype=torch.float64).log(),
                                               config=cfg, maximum_drift_norm=20.)
    return {**j, "seed": seed(j), "actual_work": 2*r.potential_evaluations,
            "joint_forward_evaluations": r.potential_evaluations, "joint_backward_evaluations": r.gradient_evaluations,
            "time_step_forward_evaluations": r.potential_evaluations*6144,
            "joint_dimension": paired.dimension, "log_normalizer": r.log_normalizer,
            "log_component_normalizers": r.log_component_normalizers.tolist(), "stages": list(r.stages),
            "wall": time.perf_counter()-begin, "guide_independent_kernel": True}


def check_unit(j: dict[str, Any], r: dict[str, Any]) -> None:
    expected = joint_work(j)
    if (any(r[k] != v for k, v in j.items()) or r["seed"] != seed(j) or r["actual_work"] != 2*expected
            or r["joint_forward_evaluations"] != expected or r["joint_backward_evaluations"] != expected
            or r["time_step_forward_evaluations"] != expected*6144 or r["joint_dimension"] != 10240
            or not r["guide_independent_kernel"]):
        raise ValueError("changed paired-grid law/binding/cost")
    v = torch.tensor(r["log_component_normalizers"], dtype=torch.float64)
    if not torch.isfinite(v).all() or abs(float(torch.logsumexp(v-math.log(2), 0))-r["log_normalizer"]) > 1e-10:
        raise ValueError("broken unnormalized component identity")


def summarize(records: list[dict[str, Any]]) -> dict[str, Any]:
    if len(records) != 32 or {identity(r) for r in records} != {identity(j) for j in jobs()}:
        raise ValueError("complete fixed resource grid required")
    rows = []
    for c in CELLS:
        for design in DESIGNS:
            group = sorted((r for r in records if r["cell"] == c and r["design"] == design), key=lambda r: r["rep"])
            logs = torch.tensor([r["log_component_normalizers"] for r in group], dtype=torch.float64)
            components = [{"grid": name, "summary": log_moments(logs[:, k]),
                           "sensitivity": sensitivity(logs[:, k].tolist(), bootstrap_seed=seed({"cell": c+name, "design": design, "rep": 1000}))}
                          for k, name in enumerate(("fine", "coarse"))]
            worst = max(r["summary"]["relative_se"] for r in components)
            required = max(32, math.ceil(3*8*(worst/.015)**2))
            work = joint_work({"design": design})
            rows.append({"cell": c, "design": design, "particles": DESIGNS[design][0], "temperature_points": DESIGNS[design][1],
                         "components": components, "paired_difference": paired_normalizer_difference(logs[:, 0], logs[:, 1], comparisons=4),
                         "initial_ancestors": [r["stages"][-1]["surviving_initial_ancestors"] for r in group],
                         "fresh_precision_forecast": {"target_rse": .015, "safety": 3, "required_wholes": required,
                                                      "physical_forward": 2*work*required, "joint_backward": work*required,
                                                      "time_step_forward": 6144*work*required,
                                                      "wall_shared_laptop_seconds": required*sum(r["wall"] for r in group)/8},
                         "scope": "pilot_allocation_forecast_not_actual_precision_or_continuum_certificate"})
    selection = {c: min((r for r in rows if r["cell"] == c),
                        key=lambda r: (r["fresh_precision_forecast"]["time_step_forward"], r["design"]))["design"] for c in CELLS}
    return {"rows": rows, "selected_development_design": selection,
            "selection_rule": "lowest_safety3_timestep_forecast_per_cell_before_fresh_confirmation",
            "p1_qualified": False, "p2_qualified": False, "large_training_authorized": False}


def run() -> dict[str, Any]:
    torch.set_num_threads(1)
    anchor = json.loads((ROOT/ANCHOR).read_text())
    config = {"model": anchor["config"]["model"], "cells": anchor["config"]["cells"], "designs": DESIGNS,
              "anchor": {"path": ANCHOR, "sha256": hashlib.sha256((ROOT/ANCHOR).read_bytes()).hexdigest()},
              "backward_cap": 2500000}
    # JSON round trip fixes tuple/list representation before all manifest hashes.
    config = json.loads(json.dumps(config))
    directory = ROOT/DIRECTORY
    directory.mkdir(parents=True, exist_ok=True)
    source = freeze_source(directory/"run.json", config, extra_snapshot_paths=(PLAN, ANCHOR))
    write_json_atomic_nonoverwriting(directory/"source.json", source)
    grid = jobs()
    if len({seed(j) for j in grid}) != 32:
        raise ValueError("seed collision")
    manifest = {"config": config, "source": source["snapshot_sha256"], "expected_units": [identity(j) for j in grid],
                "limits": {"R": {"work": 5000000, "wall": 7200.}}}
    journal, prepared = RecoveryJournal(directory, manifest), {}
    def preparation():
        prepared.update(prepare(config))
        return {"actual_work": 0}
    journal.unit("preparation", phase="R", work=0, maximum_wall=30., operation=preparation)
    records, backward = [], 0
    for j in grid:
        if backward+joint_work(j) > config["backward_cap"]:
            raise RuntimeError("backward reservation exhausted")
        if psutil.Process().memory_info().rss > 4*1024**3:
            raise MemoryError("RSS guard")
        def operation(job=j):
            r = unit_values(job, prepared[job["cell"]])
            check_unit(job, r)
            if psutil.Process().memory_info().rss > 4*1024**3:
                raise MemoryError("post-unit RSS guard")
            return r
        records.append(journal.unit(identity(j), phase="R", work=2*joint_work(j), maximum_wall=240., operation=operation))
        backward += joint_work(j)
        print(f"fine-grid resource pilot {len(records)}/32", flush=True)
    output = {"config": config, "source": source, "manifest": manifest, "summaries": summarize(records),
              "units": len(records), "work": journal.accounting("R")[0], "joint_backward_evaluations": backward,
              "time_step_forward_evaluations": sum(r["time_step_forward_evaluations"] for r in records),
              "phase_wall": time.time()-journal._read(directory/"phase-R.clock.json")["started_unix"]}
    write_json_atomic_nonoverwriting(directory/"result.json", output)
    if time.time()-journal._read(directory/"phase-R.clock.json")["started_unix"] > 7200:
        write_json_atomic_nonoverwriting(directory/"final_io_failure.json", {"status": "wall_failure"})
        raise TimeoutError("final I/O cap")
    return output


def audit(path: Path) -> dict[str, Any]:
    torch.set_num_threads(1)
    output = json.loads(path.read_text())
    config, manifest = output["config"], output["manifest"]
    audit_snapshot(ROOT, output["source"], config)
    if (config["anchor"] != {"path": ANCHOR, "sha256": hashlib.sha256((ROOT/ANCHOR).read_bytes()).hexdigest()}
            or manifest["config"] != config or manifest["source"] != output["source"]["snapshot_sha256"]
            or manifest["expected_units"] != [identity(j) for j in jobs()]):
        raise ValueError("changed source/anchor/grid")
    prepared, journal = prepare(config), RecoveryJournal(path.parent, manifest)
    records, audit_work, audit_back = [], 0, 0
    for j in jobs():
        finish = journal._read(path.parent/(identity(j)+".finish.json"))
        if finish["status"] != "complete":
            raise ValueError("failed whole")
        r = finish["result"]
        check_unit(j, r)
        if j["rep"] == 0:
            replay = unit_values(j, prepared[j["cell"]])
            if any(replay[k] != r[k] for k in ("log_normalizer", "log_component_normalizers", "stages")):
                raise ValueError("whole numerical replay mismatch")
            audit_work += replay["actual_work"]
            audit_back += replay["joint_backward_evaluations"]
        records.append(r)
    if (summarize(records) != output["summaries"] or output["units"] != 32
            or journal.accounting("R")[0] != output["work"] or output["work"] != 4108288
            or output["joint_backward_evaluations"] != 2054144
            or output["time_step_forward_evaluations"] != 12620660736
            or (path.parent/"phase-R.violation.json").exists() or (path.parent/"final_io_failure.json").exists()):
        raise ValueError("changed summaries/cost or operational failure")
    return {"status": "fine_resource_source_anchor_seed_identity_cost_replay_pass",
            "replayed_wholes": 4, "audit_physical_forward_evaluations": audit_work,
            "audit_joint_backward_evaluations": audit_back}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit")
    args = parser.parse_args()
    print(json.dumps(audit(ROOT/args.audit) if args.audit else
                     {k: v for k, v in run().items() if k in ("units", "work", "phase_wall")}))
