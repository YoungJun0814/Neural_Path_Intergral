"""Finite-grid risk potential and independent-pilot allocation (not a certificate)."""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch

from src.path_integral.r1_bottleneck_diagnostics import summarize_log_contributions


def log_risk_potential(
    log_g: torch.Tensor, log_q_over_p: torch.Tensor, *, defensive_mass: float,
) -> torch.Tensor:
    """log h = log(delta) + 2 log(g) - log(q/p); E_p[h] = delta M2(q).

    q must be frozen and contain delta*p. Strictly positive bounded payoffs only;
    no clipping or silent replacement of nonfinite values is permitted.
    """
    if (not math.isfinite(defensive_mass) or not 0 < defensive_mass <= 1
            or log_g.ndim != 1 or log_q_over_p.shape != log_g.shape
            or log_g.dtype != torch.float64 or log_q_over_p.dtype != torch.float64
            or log_g.device.type != "cpu" or log_q_over_p.device.type != "cpu"
            or not torch.isfinite(log_g).all() or not torch.isfinite(log_q_over_p).all()
            or bool((log_g > 0).any())):
        raise ValueError("risk requires finite CPU float64 log(g), 0 < g <= 1")
    if bool((log_q_over_p < math.log(defensive_mass) - 1e-12).any()):
        raise ValueError("density violates declared defensive lower bound")
    result = math.log(defensive_mass) + 2 * log_g - log_q_over_p
    if not torch.isfinite(result).all() or bool((result > 1e-12).any()):
        raise FloatingPointError("invalid bounded risk potential")
    return result


@dataclass(frozen=True)
class PrecisionAllocation:
    pilot_count: int
    target_relative_se: float
    safety_factor: float
    planned_count: int | None
    maximum_count: int
    status: str


def allocate_precision(
    pilot_log_values: torch.Tensor, *, target_relative_se: float,
    safety_factor: float, batch_size: int, maximum_count: int,
) -> PrecisionAllocation:
    """Freeze n from a disjoint pilot. Safety factor is not a confidence bound."""
    if (not math.isfinite(target_relative_se) or not 0 < target_relative_se < 1
            or not math.isfinite(safety_factor) or safety_factor < 1
            or batch_size < 2 or maximum_count < batch_size):
        raise ValueError("invalid allocation contract")
    summary = summarize_log_contributions(pilot_log_values)
    status = "allocated"
    planned: int | None = None
    if summary.relative_se is None or not math.isfinite(summary.relative_se):
        status = "unresolved_pilot"
    else:
        # RSE^2 = empirical CV^2/(n-1); convert to unbiased sample CV^2.
        cv2 = summary.relative_se**2 * summary.count
        raw = safety_factor * cv2 / target_relative_se**2
        if not math.isfinite(raw):
            status = "unresolved_pilot"
        else:
            planned = max(batch_size, math.ceil(raw / batch_size) * batch_size)
            if planned > maximum_count:
                status = "unresolved_sample_budget"
    return PrecisionAllocation(summary.count, target_relative_se, safety_factor,
                               planned, maximum_count, status)
