import math
from dataclasses import replace

import pytest
import torch

from src.path_integral.driver_conditioned_terminal import DriverConditionedTerminal
from src.path_integral.fft_driver_marginal_reference import (
    FFTDriverCovariance,
    FFTDriverMarginalReference,
)
from src.path_integral.path_functionals import TerminalThresholdTask
from src.path_integral.physical_window_guide import PhysicalWindowGuide
from tests.test_p1_recovery_p2_parallel import problem
from tests.test_physical_window_guide import KWARGS


@pytest.fixture(autouse=True)
def threads():
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


@pytest.mark.parametrize("n", [4, 16, 32])
def test_fft_covariance_projection_and_pcg_match_independent_dense_rows(n):
    p = problem(n)
    op, dense = FFTDriverCovariance.create(p), DriverConditionedTerminal.create(p)
    full = torch.randn((9, 2*n), dtype=torch.float64, generator=torch.Generator().manual_seed(27001))
    y = op.project(full)
    torch.testing.assert_close(y, full @ dense.driver_rows.T, rtol=1e-12, atol=1e-12)
    covariance = dense.driver_rows @ dense.driver_rows.T
    torch.testing.assert_close(op.covariance(y), y @ covariance, rtol=1e-12, atol=1e-12)
    solved = op.solve(y)
    expected = torch.linalg.solve(covariance, y.T).T
    torch.testing.assert_close(solved.solution, expected, rtol=1e-10, atol=1e-10)
    actual_error = torch.linalg.vector_norm(solved.solution-expected, dim=1)
    assert (actual_error <= solved.error_norm_upper+1e-12).all()
    zero = op.solve(torch.zeros((2, n-1), dtype=torch.float64))
    assert zero.iterations == 0 and torch.count_nonzero(zero.solution) == 0


@pytest.mark.parametrize("rho", [-.7, 0., .7])
def test_conditional_payoff_and_projected_mixture_density_match_independent_qr(rho):
    p = replace(problem(32), rho=rho, task=TerminalThresholdTask(80.))
    guide = PhysicalWindowGuide.create(p, kind="mixed-window", **KWARGS)
    ref, dense = FFTDriverMarginalReference.create(p, guide.spec), DriverConditionedTerminal.create(p)
    z = .5*torch.randn((16, 64), dtype=torch.float64, generator=torch.Generator().manual_seed(27002))
    x, y = dense.project(z), ref.operator.project(z)
    output = ref.evaluate(y)
    mean, variance = dense.conditional_price(x)
    torch.testing.assert_close(output.conditional_mean, mean, rtol=1e-11, atol=1e-11)
    torch.testing.assert_close(output.conditional_variance, variance, rtol=1e-11, atol=1e-11)
    torch.testing.assert_close(output.log_probability, dense.log_probability(x), rtol=1e-10, atol=1e-10)
    means = guide.spec.means @ dense.white_basis
    log_density = torch.logsumexp(x @ means.T-.5*means.square().sum(1)+guide.spec.weights.log(), 1)
    torch.testing.assert_close(output.log_density_ratio, log_density, rtol=1e-11, atol=1e-11)
    assert output.log_contribution_error_upper.max() < 1e-6
    assert (output.log_contribution <= math.log(10)+1e-10).all()


def test_solver_rejects_unconverged_run_and_autograd_instead_of_returning_approximate_silently():
    op = FFTDriverCovariance.create(problem(32))
    rhs = torch.randn((2, 31), dtype=torch.float64, generator=torch.Generator().manual_seed(27003))
    with pytest.raises(RuntimeError, match="no sample dropped"):
        op.solve(rhs, maximum_iterations=1)
    with pytest.raises(ValueError):
        op.solve(rhs.requires_grad_(True))
