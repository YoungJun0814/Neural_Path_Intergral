import pytest

from experiments.post_audit_fft_static_fine_reference import (
    DRAW_COUNT,
    WORK,
    identity,
    jobs,
    seed,
    summarize,
)


def test_static_fine_fixed_iid_blocks_joint_density_seeds_and_physical_cost():
    grid = jobs()
    assert len(grid) == len({identity(j) for j in grid}) == 16
    seeds = [seed(j, k, role) for j in grid for k in range(64) for role in ("path", "label", "augmentation")]
    assert len(seeds) == len(set(seeds)) == 3072
    assert 16*WORK == 1048576 and 16*DRAW_COUNT == 524288
    assert 16*DRAW_COUNT*6144 == 3221225472
    with pytest.raises(ValueError):
        summarize([])
