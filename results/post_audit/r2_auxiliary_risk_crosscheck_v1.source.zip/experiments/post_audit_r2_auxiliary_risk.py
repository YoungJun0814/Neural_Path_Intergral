"""Independent ordinary IS risk estimator with matched event/risk training banks."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import torch
import yaml

from experiments.post_audit_r1_diagnostics import _problem
from experiments.post_audit_r2_bank_risk_diagnostics import smc_config, smc_work
from experiments.post_audit_r2_family_diagnosis import freeze_source
from experiments.post_audit_r15_reference_crosscheck import _log_potential
from src.path_integral.baselines.weighted_conditional_ce import proposal_parameters
from src.path_integral.conditional_second_moment import (
    log_auxiliary_second_moment,
    log_risk_potential,
)
from src.path_integral.r1_bottleneck_diagnostics import summarize_log_contributions
from src.path_integral.research_result_contract import canonical_digest, source_tree_digest
from src.path_integral.seed_ledger import SeedKey, SeedLedger
from src.path_integral.weighted_bank_mixture import (
    fit_weighted_bank_mixture,
    proposal_from_parameters,
)
from src.path_integral.weighted_tempered_smc import estimate_weighted_tempered_normalizer

ROOT = Path(__file__).resolve().parents[1]


def run(config: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    torch.set_num_threads(config["torch_threads"])
    raw = (ROOT/config["proposal_artifact_path"]).read_bytes()
    original = json.loads(raw)
    protocol, ledger = "r2-aux-risk-"+canonical_digest(config)[:16], SeedLedger()
    start, work = time.perf_counter(), 0
    records = []
    for old in original["records"]:
        row_start, row_work = time.perf_counter(), work
        item = next(x for x in old["candidates"] if x["method"] == config["method"])
        if canonical_digest(item["proposal_parameters"]) != item["proposal_digest"]:
            raise ValueError("q binding mismatch")
        q = proposal_from_parameters(item["proposal_parameters"])
        problem = _problem(original["config"]["model"], old["cell"], original["config"]["smc"]["steps"])
        row: dict[str, Any] = {"cell": old["cell"], "parent_training_rep": old["parent_training_rep"],
            "q_digest": item["proposal_digest"], "estimators": [], "training": [], "failure_reasons": []}
        records.append(row)

        def seed(role: str, regime: str, level: int, stream: str,
                 task: str = problem.task_id, rep: int = old["parent_training_rep"]) -> int:
            return ledger.allocate(SeedKey(protocol, role, regime, task, level, rep, stream))

        def check(n: int) -> None:
            if work+n > config["budget"]["max_potential_evaluations"]:
                raise TimeoutError("unresolved_potential_budget")
            if time.perf_counter()-start >= config["budget"]["max_wall_seconds"]:
                raise TimeoutError("unresolved_wall_budget")

        def payoff(x: torch.Tensor, fixed_problem: Any = problem) -> torch.Tensor:
            nonlocal work
            check(len(x))
            work += len(x)
            return _log_potential(fixed_problem, x)

        try:
            auxiliaries = [("direct-q", q)]
            for kind in ("event", "risk"):
                stage, stage_work = time.perf_counter(), work
                samples, weights = [], []
                spec = config["training"]

                def potential(x: torch.Tensor, mode: str = kind, fixed_q: Any = q) -> torch.Tensor:
                    logg = payoff(x)
                    return logg if mode == "event" else log_risk_potential(logg, fixed_q.log_q_over_p(x),
                                                                         defensive_mass=fixed_q.defensive_mass)

                for island in range(spec["islands"]):
                    check(smc_work(spec, spec["particles"]))
                    bank = estimate_weighted_tempered_normalizer(potential, dimension=problem.local_dimension,
                        config=smc_config(spec, seed=seed("auxiliary-training", kind, island, "whole"), retain=True))
                    if bank.final_particles is None or bank.final_weights is None:
                        raise RuntimeError("missing auxiliary training bank")
                    samples.append(bank.final_particles)
                    weights.append(bank.final_weights/spec["islands"])
                fit = fit_weighted_bank_mixture(torch.cat(samples), torch.cat(weights), **config["mixture"])
                auxiliaries.append((kind+"-auxiliary", fit.proposal))
                row["training"].append({"kind": kind, "potential_evaluations": work-stage_work,
                    "wall_seconds": time.perf_counter()-stage, "weighted_particle_ess": fit.weighted_bank_ess})
            # r candidates all frozen before any final risk observations.
            for name, r in auxiliaries:
                row["estimators"].append({"id": name, "r_parameters": proposal_parameters(r),
                    "r_digest": canonical_digest(proposal_parameters(r)), "batches": [], "failure_reasons": []})
            for (name, r), result in zip(auxiliaries, row["estimators"], strict=True):
                stage, stage_work = time.perf_counter(), work
                logs = []
                try:
                    spec = config["evaluation"]
                    for batch in range(math.ceil(spec["count"]/spec["batch_size"])):
                        n = min(spec["batch_size"], spec["count"]-batch*spec["batch_size"])
                        check(n)
                        draw = r.sample(n, path_seed=seed("auxiliary-final", name, batch, "path"),
                                        label_seed=seed("auxiliary-final", name, batch, "label"))
                        values = log_auxiliary_second_moment(payoff(draw.samples), q.log_q_over_p(draw.samples),
                                                             draw.log_q_over_p)
                        logs.append(values)
                        result["batches"].append(asdict(summarize_log_contributions(values)))
                    result["summary"] = asdict(summarize_log_contributions(torch.cat(logs)))
                    result["precision_pass"] = result["summary"]["relative_se"] <= spec["maximum_relative_se"]
                    result["status"] = "completed_development"
                except (ValueError, FloatingPointError, RuntimeError, TimeoutError) as error:
                    result["status"] = "unresolved"
                    result["precision_pass"] = False
                    result["failure_reasons"].append(f"{type(error).__name__}: {error}")
                result["potential_evaluations"] = work-stage_work
                result["wall_seconds_including_failure"] = time.perf_counter()-stage
            row["status"] = "completed_development"
        except (ValueError, FloatingPointError, RuntimeError, TimeoutError) as error:
            row["status"] = "unresolved"
            row["failure_reasons"].append(f"{type(error).__name__}: {error}")
        row["potential_evaluations"] = work-row_work
        row["wall_seconds_including_failure"] = time.perf_counter()-row_start
        print(json.dumps({"finished": [old["cell"]["id"], old["parent_training_rep"]], "status": row["status"]}), flush=True)
    if source_tree_digest(ROOT) != source["source_tree_digest"]:
        raise RuntimeError("source changed during experiment")
    return {"schema": "npi.post-audit.r2-aux-risk.v1", "config": config, "source": source,
        "proposal_artifact_sha256": hashlib.sha256(raw).hexdigest(), "records": records,
        "seed_ledger": ledger.to_dict(), "potential_evaluations": work, "physical_wall_seconds": time.perf_counter()-start,
        "model_q_changed": False, "performance_claim_authorized": False}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT/"configs/post_audit/r2_auxiliary_risk_crosscheck_v1.yaml")
    args = parser.parse_args()
    config = yaml.safe_load(args.config.read_text(encoding="utf-8"))
    output = ROOT/config["output_path"]
    if output.exists():
        raise FileExistsError(output)
    source = freeze_source(output, config)
    result = run(config, source)
    with output.open("x", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, allow_nan=False)
    print(json.dumps({"output": str(output), "work": result["potential_evaluations"], "wall_seconds": result["physical_wall_seconds"]}), flush=True)


if __name__ == "__main__":
    main()
